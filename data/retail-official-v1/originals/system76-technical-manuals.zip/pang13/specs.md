---
title: Pangolin (pang13)
---

- [External Overview](./external-overview.mdx)
- [Internal Overview](./internal-overview.md)
- [Parts & Repairs](./repairs.md)

![Pangolin](./img/pang13.webp)

The System76 Pangolin is a laptop with the following specifications:

- CPU
    - Supports AMD Ryzen (Rembrandt) Mobile CPUs
        - [Ryzen 7 7735U](https://www.amd.com/en/products/apu/amd-ryzen-7-7735u)
- BIOS
    - Winbond W25R256JW flash chip
        - WSON-8 form factor
    - Programmed with System76 firmware (non-open)
- EC
    - ITE IT5571
        - Programmed with non-open EC firmware
- Graphics
    - GPU: AMD Radeon 680M
    - eDP display: 15.6" 1920x1080@144Hz LCD
        - LCD panel: Innolux N156HRA-EA1 (or equivalent)
    - External video output: 
        - 1x HDMI 2.0
        - 1x DisplayPort 1.4 over USB-C
- Memory
    - 32GB (4x8GB) LPDDR5 (on-board) @ 6400 MHz
        - [Micron MT62F2G32D8DR-031](https://www.micron.com/products/memory/dram-components/lpddr5/part-catalog/part-detail/mt62f2g32d8dr-031-wt-b)
        - [SK Hynix H9JCNNNFA5MLYR-N6E](https://product.skhynix.com/products/dram/lpddr/lpddr5.go?appTypCd=APX02&treeNo=1054)
        - ...or other equivalent.
- Networking
    - Gigabit Ethernet
    - M.2 PCIe WiFi/Bluetooth
        - Mediatek MT7921K
- Power
    - 90W (19V, 4.74A) DC-in port
        - Barrel size: 5.5mm (outer), 2.5mm (inner)
    - Included AC adapter: ShenZhen SOY-1900474
        - AC power cord type: IEC C13
    - USB-C charging compatible with 90W+ charger
    - 70Wh 3-cell Lithium-Ion battery
        - Model number: 628467-3S1P
- Sound
    - Internal speakers & microphone
    - Combined headphone & microphone 3.5mm jack
    - HDMI audio
- Storage
    - 2x M.2 (PCIe NVMe Gen 4)
    - SD card reader
- USB
    - 1x USB 3.2 Gen 2 Type-C
        - Supports DisplayPort over USB-C
        - Supports USB-C charging (USB-PD)
        - Does not support Thunderbolt
    - 3x USB 3.2 Gen 1 Type-A
- Dimensions
    - 1.80cm x 37.06cm x 24.79cm, 1.79kg
